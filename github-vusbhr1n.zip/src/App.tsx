import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { InvoiceProvider } from "@/contexts/InvoiceContext";
import { ClientProvider } from "@/contexts/ClientContext";
import { ExpenseProvider } from "@/contexts/ExpenseContext";
import { RevenueProvider } from "@/contexts/RevenueContext";
import { BudgetProvider } from "@/contexts/BudgetContext";
import { LedgerProvider } from "@/contexts/LedgerContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import Index from "./pages/Index";
import Features from "./pages/Features";
import Pricing from "./pages/Pricing";
import About from "./pages/About";
import Help from "./pages/Help";
import Careers from "./pages/Careers";
import NotFound from "./pages/NotFound";
import ApplicationsAdmin from "./pages/ApplicationsAdmin";
import Dashboard from "./pages/Dashboard";
import Invoicing from "./pages/Invoicing";
import Expenses from "./pages/Expenses";
import Clients from "./pages/Clients";
import Revenue from "./pages/Revenue";
import Budget from "./pages/Budget";
import Ledger from "./pages/Ledger";
import Settings from "./pages/Settings";
import FinancialReports from "./pages/FinancialReports";
import Auth from "./pages/Auth";
import Onboarding from "./pages/Onboarding";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <BrowserRouter>
      <AuthProvider>
        <TooltipProvider>
          <RevenueProvider>
            <BudgetProvider>
              <LedgerProvider>
                <ClientProvider>
                  <InvoiceProvider>
                    <ExpenseProvider>
                      <Toaster />
                      <Sonner />
                      <Routes>
                        {/* Public routes */}
                        <Route path="/" element={<Index />} />
                        <Route path="/features" element={<Features />} />
                        <Route path="/pricing" element={<Pricing />} />
                        <Route path="/about" element={<About />} />
                        <Route path="/help" element={<Help />} />
                        <Route path="/careers" element={<Careers />} />
                        <Route path="/auth" element={<Auth />} />
                        
                        {/* Protected routes */}
                        <Route path="/onboarding" element={
                          <ProtectedRoute>
                            <Onboarding />
                          </ProtectedRoute>
                        } />
                        <Route path="/dashboard" element={
                          <ProtectedRoute>
                            <Dashboard />
                          </ProtectedRoute>
                        } />
                        <Route path="/invoicing" element={
                          <ProtectedRoute>
                            <Invoicing />
                          </ProtectedRoute>
                        } />
                        <Route path="/expenses" element={
                          <ProtectedRoute>
                            <Expenses />
                          </ProtectedRoute>
                        } />
                        <Route path="/clients" element={
                          <ProtectedRoute>
                            <Clients />
                          </ProtectedRoute>
                        } />
                        <Route path="/revenue" element={
                          <ProtectedRoute>
                            <Revenue />
                          </ProtectedRoute>
                        } />
                        <Route path="/budget" element={
                          <ProtectedRoute>
                            <Budget />
                          </ProtectedRoute>
                        } />
                        <Route path="/ledger" element={
                          <ProtectedRoute>
                            <Ledger />
                          </ProtectedRoute>
                        } />
                        <Route path="/reports" element={
                          <ProtectedRoute>
                            <FinancialReports />
                          </ProtectedRoute>
                        } />
                        <Route path="/settings" element={
                          <ProtectedRoute>
                            <Settings />
                          </ProtectedRoute>
                        } />
                        <Route path="/admin/applications" element={
                          <ProtectedRoute>
                            <ApplicationsAdmin />
                          </ProtectedRoute>
                        } />
                        
                        {/* Catch all route */}
                        <Route path="*" element={<NotFound />} />
                      </Routes>
                    </ExpenseProvider>
                  </InvoiceProvider>
                </ClientProvider>
              </LedgerProvider>
            </BudgetProvider>
          </RevenueProvider>
        </TooltipProvider>
      </AuthProvider>
    </BrowserRouter>
  </QueryClientProvider>
);

export default App;