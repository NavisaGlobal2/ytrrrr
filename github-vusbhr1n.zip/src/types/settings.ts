export type BusinessProfile = {
  logo?: string;
  name: string;
  industry: string;
  email: string;
  timezone: string;
  country: string;
  state: string;
  phone1: string;
  phone2?: string;
  address1: string;
  address2?: string;
};

export type NotificationSettings = {
  emailNotifications: boolean;
  pushNotifications: boolean;
  smsNotifications: boolean;
};

export type TeamMember = {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'member' | 'viewer';
  status: 'active' | 'invited' | 'disabled';
};

export type IntegrationProvider = {
  id: string;
  name: string;
  description: string;
  connected: boolean;
  icon: string;
};