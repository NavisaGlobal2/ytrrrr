export type RevenueSource = 'client' | 'product' | 'service';
export type PaymentStatus = 'paid' | 'unpaid' | 'overdue';

export interface Revenue {
  id: string;
  revenueNumber: string;
  date: Date;
  source: RevenueSource;
  amount: number;
  description: string;
  status: PaymentStatus;
}

export interface RevenueStats {
  totalReceivables: number;
  outstandingReceivables: number;
}