export type BudgetCategory = 
  | 'salary'
  | 'rent'
  | 'utilities'
  | 'marketing'
  | 'software'
  | 'hardware'
  | 'travel'
  | 'office'
  | 'other';

export type BudgetStatus = 'active' | 'draft' | 'archived';

export interface BudgetItem {
  id: string;
  category: BudgetCategory;
  amount: number;
  spent: number;
  remaining: number;
  description?: string;
}

export interface Budget {
  id: string;
  name: string;
  startDate: Date;
  endDate: Date;
  status: BudgetStatus;
  totalBudget: number;
  totalSpent: number;
  items: BudgetItem[];
}