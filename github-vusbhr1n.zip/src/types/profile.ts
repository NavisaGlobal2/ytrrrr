export interface BusinessProfile {
  id: string;
  business_name?: string;
  industry?: string;
  tax_number?: string;
  rc_number: string; // Required
  business_type?: string;
  registration_date?: string;
  vat_number?: string;
  phone?: string;
  website?: string;
  address?: string;
  created_at: string;
}