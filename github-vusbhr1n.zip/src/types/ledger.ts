export type TransactionType = 'debit' | 'credit';
export type TransactionStatus = 'pending' | 'posted' | 'voided';

export interface LedgerTransaction {
  id: string;
  date: Date;
  description: string;
  type: TransactionType;
  amount: number;
  status: TransactionStatus;
  reference?: string;
  notes?: string;
}

export interface LedgerAccount {
  id: string;
  name: string;
  number: string;
  balance: number;
  transactions: LedgerTransaction[];
}