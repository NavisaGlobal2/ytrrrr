import React, { createContext, useContext, useState, useEffect } from 'react';
import { Revenue, RevenueSource, PaymentStatus } from '@/types/revenue';
import { format } from 'date-fns';

interface RevenueContextType {
  revenues: Revenue[];
  addRevenue: (revenue: Omit<Revenue, 'id' | 'revenueNumber'>) => void;
  updateRevenueStatus: (id: string, status: PaymentStatus) => void;
  deleteRevenue: (id: string) => void;
  getTotalReceivables: () => number;
  getOutstandingReceivables: () => number;
  importRevenues: (revenues: Omit<Revenue, 'id' | 'revenueNumber'>[]) => void;
}

const RevenueContext = createContext<RevenueContextType | undefined>(undefined);

export const useRevenue = () => {
  const context = useContext(RevenueContext);
  if (!context) {
    throw new Error('useRevenue must be used within a RevenueProvider');
  }
  return context;
};

export const RevenueProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [revenues, setRevenues] = useState<Revenue[]>([]);

  // Load revenues from localStorage on mount
  useEffect(() => {
    const storedRevenues = localStorage.getItem('revenues');
    if (storedRevenues) {
      try {
        const parsedRevenues = JSON.parse(storedRevenues);
        setRevenues(parsedRevenues.map((rev: any) => ({
          ...rev,
          date: new Date(rev.date)
        })));
      } catch (error) {
        console.error("Failed to parse stored revenues:", error);
      }
    }
  }, []);

  // Save revenues to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('revenues', JSON.stringify(revenues));
  }, [revenues]);

  const getNextRevenueNumber = () => {
    const year = new Date().getFullYear().toString().slice(-2);
    const month = (new Date().getMonth() + 1).toString().padStart(2, '0');
    const prefix = `REV-${year}${month}-`;
    
    const existingNumbers = revenues
      .map(rev => rev.revenueNumber)
      .filter(num => num.startsWith(prefix))
      .map(num => parseInt(num.replace(prefix, ''), 10));
    
    const nextNumber = existingNumbers.length > 0
      ? Math.max(...existingNumbers) + 1
      : 1;
    
    return `${prefix}${nextNumber.toString().padStart(3, '0')}`;
  };

  const addRevenue = (revenueData: Omit<Revenue, 'id' | 'revenueNumber'>) => {
    const newRevenue: Revenue = {
      ...revenueData,
      id: crypto.randomUUID(),
      revenueNumber: getNextRevenueNumber(),
    };
    
    setRevenues(prev => [newRevenue, ...prev]);
  };

  const updateRevenueStatus = (id: string, status: PaymentStatus) => {
    setRevenues(prev => 
      prev.map(revenue => 
        revenue.id === id 
          ? { ...revenue, status } 
          : revenue
      )
    );
  };

  const deleteRevenue = (id: string) => {
    setRevenues(prev => prev.filter(revenue => revenue.id !== id));
  };

  const getTotalReceivables = () => {
    return revenues.reduce((total, revenue) => total + revenue.amount, 0);
  };

  const getOutstandingReceivables = () => {
    return revenues
      .filter(revenue => revenue.status !== 'paid')
      .reduce((total, revenue) => total + revenue.amount, 0);
  };

  const importRevenues = (newRevenues: Omit<Revenue, 'id' | 'revenueNumber'>[]) => {
    const importedRevenues = newRevenues.map(revenue => ({
      ...revenue,
      id: crypto.randomUUID(),
      revenueNumber: getNextRevenueNumber(),
    }));
    
    setRevenues(prev => [...importedRevenues, ...prev]);
  };

  return (
    <RevenueContext.Provider value={{ 
      revenues, 
      addRevenue,
      updateRevenueStatus,
      deleteRevenue,
      getTotalReceivables,
      getOutstandingReceivables,
      importRevenues
    }}>
      {children}
    </RevenueContext.Provider>
  );
};