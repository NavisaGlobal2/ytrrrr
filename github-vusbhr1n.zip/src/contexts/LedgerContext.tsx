import React, { createContext, useContext, useState, useEffect } from 'react';
import { LedgerTransaction, LedgerAccount, TransactionStatus } from '@/types/ledger';

interface LedgerContextType {
  transactions: LedgerTransaction[];
  accounts: LedgerAccount[];
  addTransaction: (transaction: Omit<LedgerTransaction, 'id' | 'status'>) => void;
  updateTransactionStatus: (id: string, status: TransactionStatus) => void;
  deleteTransaction: (id: string) => void;
  getTotalTransactions: () => number;
}

const LedgerContext = createContext<LedgerContextType | undefined>(undefined);

export const useLedger = () => {
  const context = useContext(LedgerContext);
  if (!context) {
    throw new Error('useLedger must be used within a LedgerProvider');
  }
  return context;
};

export const LedgerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [transactions, setTransactions] = useState<LedgerTransaction[]>([]);
  const [accounts, setAccounts] = useState<LedgerAccount[]>([]);

  // Load transactions from localStorage on mount
  useEffect(() => {
    const storedTransactions = localStorage.getItem('ledger_transactions');
    if (storedTransactions) {
      try {
        const parsedTransactions = JSON.parse(storedTransactions);
        setTransactions(parsedTransactions.map((tx: any) => ({
          ...tx,
          date: new Date(tx.date)
        })));
      } catch (error) {
        console.error("Failed to parse stored transactions:", error);
      }
    }
  }, []);

  // Save transactions to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('ledger_transactions', JSON.stringify(transactions));
  }, [transactions]);

  const addTransaction = (transactionData: Omit<LedgerTransaction, 'id' | 'status'>) => {
    const newTransaction: LedgerTransaction = {
      ...transactionData,
      id: crypto.randomUUID(),
      status: 'pending'
    };
    
    setTransactions(prev => [newTransaction, ...prev]);
  };

  const updateTransactionStatus = (id: string, status: TransactionStatus) => {
    setTransactions(prev => 
      prev.map(transaction => 
        transaction.id === id 
          ? { ...transaction, status } 
          : transaction
      )
    );
  };

  const deleteTransaction = (id: string) => {
    setTransactions(prev => prev.filter(transaction => transaction.id !== id));
  };

  const getTotalTransactions = () => {
    return transactions.length;
  };

  return (
    <LedgerContext.Provider value={{ 
      transactions, 
      accounts,
      addTransaction,
      updateTransactionStatus,
      deleteTransaction,
      getTotalTransactions
    }}>
      {children}
    </LedgerContext.Provider>
  );
};