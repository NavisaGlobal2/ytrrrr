import React, { createContext, useContext, useState, useEffect } from 'react';
import { Budget, BudgetStatus, BudgetItem } from '@/types/budget';

interface BudgetContextType {
  budgets: Budget[];
  addBudget: (budget: Omit<Budget, 'id'>) => void;
  updateBudget: (id: string, budget: Partial<Budget>) => void;
  deleteBudget: (id: string) => void;
  getBudgetById: (id: string) => Budget | undefined;
  getTotalBudget: () => number;
  getTotalSpent: () => number;
}

const BudgetContext = createContext<BudgetContextType | undefined>(undefined);

export const useBudget = () => {
  const context = useContext(BudgetContext);
  if (!context) {
    throw new Error('useBudget must be used within a BudgetProvider');
  }
  return context;
};

export const BudgetProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [budgets, setBudgets] = useState<Budget[]>([]);

  // Load budgets from localStorage on mount
  useEffect(() => {
    const storedBudgets = localStorage.getItem('budgets');
    if (storedBudgets) {
      try {
        const parsedBudgets = JSON.parse(storedBudgets);
        setBudgets(parsedBudgets.map((budget: any) => ({
          ...budget,
          startDate: new Date(budget.startDate),
          endDate: new Date(budget.endDate)
        })));
      } catch (error) {
        console.error("Failed to parse stored budgets:", error);
      }
    }
  }, []);

  // Save budgets to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('budgets', JSON.stringify(budgets));
  }, [budgets]);

  const addBudget = (budgetData: Omit<Budget, 'id'>) => {
    const newBudget: Budget = {
      ...budgetData,
      id: crypto.randomUUID(),
    };
    
    setBudgets(prev => [newBudget, ...prev]);
  };

  const updateBudget = (id: string, budgetData: Partial<Budget>) => {
    setBudgets(prev => 
      prev.map(budget => 
        budget.id === id 
          ? { ...budget, ...budgetData } 
          : budget
      )
    );
  };

  const deleteBudget = (id: string) => {
    setBudgets(prev => prev.filter(budget => budget.id !== id));
  };

  const getBudgetById = (id: string) => {
    return budgets.find(budget => budget.id === id);
  };

  const getTotalBudget = () => {
    return budgets.reduce((total, budget) => total + budget.totalBudget, 0);
  };

  const getTotalSpent = () => {
    return budgets.reduce((total, budget) => total + budget.totalSpent, 0);
  };

  return (
    <BudgetContext.Provider value={{ 
      budgets, 
      addBudget,
      updateBudget,
      deleteBudget,
      getBudgetById,
      getTotalBudget,
      getTotalSpent
    }}>
      {children}
    </BudgetContext.Provider>
  );
};