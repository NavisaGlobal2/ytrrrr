import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

// Generic database operations
export const useDatabase = () => {
  const { user } = useAuth();

  const fetchAll = async (table: string) => {
    if (!user) throw new Error("User not authenticated");

    const { data, error } = await supabase
      .from(table)
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  };

  const insert = async (table: string, data: any) => {
    if (!user) throw new Error("User not authenticated");

    const { data: result, error } = await supabase
      .from(table)
      .insert({
        ...data,
        user_id: user.id
      })
      .select()
      .single();

    if (error) throw error;
    return result;
  };

  const update = async (table: string, id: string, data: any) => {
    if (!user) throw new Error("User not authenticated");

    const { data: result, error } = await supabase
      .from(table)
      .update(data)
      .eq('id', id)
      .eq('user_id', user.id)
      .select()
      .single();

    if (error) throw error;
    return result;
  };

  const remove = async (table: string, id: string) => {
    if (!user) throw new Error("User not authenticated");

    const { error } = await supabase
      .from(table)
      .delete()
      .eq('id', id)
      .eq('user_id', user.id);

    if (error) throw error;
  };

  return {
    fetchAll,
    insert,
    update,
    remove
  };
};

// Profile operations
export const useProfile = () => {
  const { user } = useAuth();

  const fetchProfile = async () => {
    if (!user) throw new Error("User not authenticated");

    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single();

    if (error && error.code !== 'PGRST116') throw error;
    return data;
  };

  const updateProfile = async (data: any) => {
    if (!user) throw new Error("User not authenticated");

    const { data: result, error } = await supabase
      .from('profiles')
      .upsert({
        id: user.id,
        updated_at: new Date().toISOString(),
        ...data
      })
      .select()
      .single();

    if (error) throw error;
    return result;
  };

  return {
    fetchProfile,
    updateProfile
  };
};

// Other database operations...
export const useInvoices = () => {
  const db = useDatabase();
  return {
    fetchInvoices: () => db.fetchAll('invoices'),
    createInvoice: (data: any) => db.insert('invoices', data),
    updateInvoice: (id: string, data: any) => db.update('invoices', id, data),
    deleteInvoice: (id: string) => db.remove('invoices', id)
  };
};

export const useExpenses = () => {
  const db = useDatabase();
  return {
    fetchExpenses: () => db.fetchAll('expenses'),
    createExpense: (data: any) => db.insert('expenses', data),
    updateExpense: (id: string, data: any) => db.update('expenses', id, data),
    deleteExpense: (id: string) => db.remove('expenses', id)
  };
};

export const useRevenues = () => {
  const db = useDatabase();
  return {
    fetchRevenues: () => db.fetchAll('revenues'),
    createRevenue: (data: any) => db.insert('revenues', data),
    updateRevenue: (id: string, data: any) => db.update('revenues', id, data),
    deleteRevenue: (id: string) => db.remove('revenues', id)
  };
};

export const useBudgets = () => {
  const db = useDatabase();
  return {
    fetchBudgets: () => db.fetchAll('budgets'),
    createBudget: (data: any) => db.insert('budgets', data),
    updateBudget: (id: string, data: any) => db.update('budgets', id, data),
    deleteBudget: (id: string) => db.remove('budgets', id)
  };
};

export const useTransactions = () => {
  const db = useDatabase();
  return {
    fetchTransactions: () => db.fetchAll('transactions'),
    createTransaction: (data: any) => db.insert('transactions', data),
    updateTransaction: (id: string, data: any) => db.update('transactions', id, data),
    deleteTransaction: (id: string) => db.remove('transactions', id)
  };
};

export const useClients = () => {
  const db = useDatabase();
  return {
    fetchClients: () => db.fetchAll('clients'),
    createClient: (data: any) => db.insert('clients', data),
    updateClient: (id: string, data: any) => db.update('clients', id, data),
    deleteClient: (id: string) => db.remove('clients', id)
  };
};