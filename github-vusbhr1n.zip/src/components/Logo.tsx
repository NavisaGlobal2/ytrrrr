import React from "react";

export const Logo = ({ className = "" }: { className?: string }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width="32" 
    height="32" 
    viewBox="0 0 375 375" 
    className={className}
  >
    <defs>
      <clipPath id="logoClip1">
        <path d="M 82.453125 82.339844 L 293 82.339844 L 293 293 L 82.453125 293 Z M 82.453125 82.339844" />
      </clipPath>
      <clipPath id="logoClip2">
        <path d="M 268.683594 268.757812 L 199.464844 268.757812 L 199.464844 106.191406 L 258.789062 106.191406 L 268.683594 116.085938 Z M 268.683594 82.339844 L 106.300781 82.339844 L 82.453125 106.191406 L 82.453125 139.9375 L 116.199219 106.191406 L 175.566406 106.191406 L 175.566406 268.757812 L 106.347656 268.757812 L 106.347656 139.984375 L 82.453125 163.832031 L 82.453125 292.65625 L 292.582031 292.65625 L 292.582031 106.191406 Z M 268.683594 82.339844" />
      </clipPath>
    </defs>
    <g clipPath="url(#logoClip1)">
      <g clipPath="url(#logoClip2)">
        <path 
          fill="#05d166" 
          d="M 82.453125 82.339844 L 292.546875 82.339844 L 292.546875 292.4375 L 82.453125 292.4375 Z M 82.453125 82.339844"
          fillOpacity="1"
          fillRule="nonzero"
        />
      </g>
    </g>
  </svg>
);