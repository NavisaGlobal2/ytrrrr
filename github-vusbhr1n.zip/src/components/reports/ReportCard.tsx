import { Card } from "@/components/ui/card";

interface ReportCardProps {
  title: string;
  description: string;
  variant: "blue" | "yellow" | "green";
  onClick: () => void;
}

const variantStyles = {
  blue: "bg-blue-50 hover:bg-blue-100",
  yellow: "bg-yellow-50 hover:bg-yellow-100",
  green: "bg-green-50 hover:bg-green-100"
};

export const ReportCard = ({ title, description, variant, onClick }: ReportCardProps) => {
  return (
    <Card 
      className={`p-6 cursor-pointer transition-colors ${variantStyles[variant]}`}
      onClick={onClick}
    >
      <h3 className="font-semibold mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
    </Card>
  );
};