import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useBudget } from "@/contexts/BudgetContext";
import { BudgetCategory } from "@/types/budget";
import { toast } from "sonner";

interface CreateBudgetDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const BUDGET_CATEGORIES: { value: BudgetCategory; label: string }[] = [
  { value: "salary", label: "Salary" },
  { value: "rent", label: "Rent" },
  { value: "utilities", label: "Utilities" },
  { value: "marketing", label: "Marketing" },
  { value: "software", label: "Software" },
  { value: "hardware", label: "Hardware" },
  { value: "travel", label: "Travel" },
  { value: "office", label: "Office" },
  { value: "other", label: "Other" },
];

export const CreateBudgetDialog = ({ open, onOpenChange }: CreateBudgetDialogProps) => {
  const { addBudget } = useBudget();
  const [name, setName] = useState("");
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState("");
  const [items, setItems] = useState<Array<{ category: BudgetCategory; amount: string }>>([
    { category: "salary", amount: "" }
  ]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) {
      toast.error("Please enter a budget name");
      return;
    }
    
    if (!startDate || !endDate) {
      toast.error("Please select both start and end dates");
      return;
    }

    if (new Date(endDate) <= new Date(startDate)) {
      toast.error("End date must be after start date");
      return;
    }

    const validItems = items.filter(item => item.amount && !isNaN(Number(item.amount)));
    if (validItems.length === 0) {
      toast.error("Please add at least one budget item with a valid amount");
      return;
    }

    const budgetItems = validItems.map(item => ({
      id: crypto.randomUUID(),
      category: item.category,
      amount: Number(item.amount),
      spent: 0,
      remaining: Number(item.amount)
    }));

    const totalBudget = budgetItems.reduce((sum, item) => sum + item.amount, 0);

    addBudget({
      name,
      startDate: new Date(startDate),
      endDate: new Date(endDate),
      status: "active",
      totalBudget,
      totalSpent: 0,
      items: budgetItems
    });

    toast.success("Budget created successfully");
    onOpenChange(false);
    resetForm();
  };

  const resetForm = () => {
    setName("");
    setStartDate(new Date().toISOString().split('T')[0]);
    setEndDate("");
    setItems([{ category: "salary", amount: "" }]);
  };

  const addBudgetItem = () => {
    setItems([...items, { category: "salary", amount: "" }]);
  };

  const removeBudgetItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Create New Budget</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Budget Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter budget name"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startDate">Start Date</Label>
              <Input
                id="startDate"
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="endDate">End Date</Label>
              <Input
                id="endDate"
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                min={startDate}
              />
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>Budget Items</Label>
              <Button 
                type="button" 
                variant="outline" 
                onClick={addBudgetItem}
                className="text-xs"
              >
                Add Item
              </Button>
            </div>

            {items.map((item, index) => (
              <div key={index} className="grid grid-cols-[1fr,1fr,auto] gap-4 items-end">
                <div className="space-y-2">
                  <Label htmlFor={`category-${index}`}>Category</Label>
                  <select
                    id={`category-${index}`}
                    value={item.category}
                    onChange={(e) => {
                      const newItems = [...items];
                      newItems[index].category = e.target.value as BudgetCategory;
                      setItems(newItems);
                    }}
                    className="w-full h-10 px-3 rounded-md border border-input bg-background"
                  >
                    {BUDGET_CATEGORIES.map((cat) => (
                      <option key={cat.value} value={cat.value}>
                        {cat.label}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`amount-${index}`}>Amount</Label>
                  <Input
                    id={`amount-${index}`}
                    type="number"
                    value={item.amount}
                    onChange={(e) => {
                      const newItems = [...items];
                      newItems[index].amount = e.target.value;
                      setItems(newItems);
                    }}
                    placeholder="Enter amount"
                    min="0"
                    step="0.01"
                  />
                </div>

                {items.length > 1 && (
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => removeBudgetItem(index)}
                    className="text-red-500 hover:text-red-600"
                  >
                    Remove
                  </Button>
                )}
              </div>
            ))}
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" className="bg-green-500 hover:bg-green-600 text-white">
              Create Budget
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};