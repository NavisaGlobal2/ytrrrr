import { useState } from "react";
import { Button } from "@/components/ui/button";
import { IntegrationProvider } from "@/types/settings";
import { toast } from "sonner";

export const IntegrationsSettings = () => {
  const [integrations] = useState<IntegrationProvider[]>([
    {
      id: 'paystack',
      name: 'Paystack',
      description: 'Accept payments from customers',
      connected: true,
      icon: '💳'
    },
    {
      id: 'google',
      name: 'Google Workspace',
      description: 'Sync with Google Calendar and Drive',
      connected: false,
      icon: '🔄'
    }
  ]);

  const handleConnect = (id: string) => {
    toast.success(`Connected to ${id} successfully`);
  };

  const handleDisconnect = (id: string) => {
    toast.success(`Disconnected from ${id}`);
  };

  return (
    <div className="max-w-4xl">
      <h2 className="text-lg font-medium mb-6">Connected services</h2>

      <div className="space-y-4">
        {integrations.map((integration) => (
          <div key={integration.id} className="border rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="text-2xl">{integration.icon}</div>
                <div>
                  <div className="font-medium">{integration.name}</div>
                  <div className="text-sm text-muted-foreground">
                    {integration.description}
                  </div>
                </div>
              </div>
              <Button
                variant={integration.connected ? "outline" : "default"}
                onClick={() => integration.connected 
                  ? handleDisconnect(integration.id)
                  : handleConnect(integration.id)
                }
              >
                {integration.connected ? "Disconnect" : "Connect"}
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};