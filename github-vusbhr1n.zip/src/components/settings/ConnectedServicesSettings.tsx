import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface ConnectedService {
  id: string;
  name: string;
  description: string;
  status: 'connected' | 'disconnected';
  apiKey?: string;
  icon: string;
}

export const ConnectedServicesSettings = () => {
  const [services, setServices] = useState<ConnectedService[]>([
    {
      id: 'paystack',
      name: 'Paystack',
      description: 'Payment processing and transactions',
      status: 'connected',
      icon: '💳',
    },
    {
      id: 'mono',
      name: 'Mono',
      description: 'Bank account data and transactions',
      status: 'disconnected',
      icon: '🏦',
    },
    {
      id: 'google',
      name: 'Google Drive',
      description: 'Document storage and backup',
      status: 'disconnected',
      icon: '📁',
    },
    {
      id: 'slack',
      name: 'Slack',
      description: 'Team notifications and alerts',
      status: 'disconnected',
      icon: '💬',
    }
  ]);

  const [selectedService, setSelectedService] = useState<ConnectedService | null>(null);
  const [showApiKeyDialog, setShowApiKeyDialog] = useState(false);
  const [apiKey, setApiKey] = useState("");

  const handleConnect = (service: ConnectedService) => {
    setSelectedService(service);
    setShowApiKeyDialog(true);
  };

  const handleDisconnect = (serviceId: string) => {
    setServices(services.map(service => 
      service.id === serviceId 
        ? { ...service, status: 'disconnected' as const, apiKey: undefined }
        : service
    ));
    toast.success(`Disconnected from ${serviceId} successfully`);
  };

  const handleSaveApiKey = () => {
    if (!apiKey.trim()) {
      toast.error("Please enter an API key");
      return;
    }

    if (selectedService) {
      setServices(services.map(service =>
        service.id === selectedService.id
          ? { ...service, status: 'connected' as const, apiKey }
          : service
      ));
      toast.success(`Connected to ${selectedService.name} successfully`);
      setShowApiKeyDialog(false);
      setApiKey("");
      setSelectedService(null);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-medium mb-2">Connected Services</h2>
        <p className="text-sm text-muted-foreground">
          Manage your integrations and API connections
        </p>
      </div>

      <div className="grid gap-4">
        {services.map((service) => (
          <Card key={service.id} className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="text-3xl">{service.icon}</div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-medium">{service.name}</h3>
                    <Badge 
                      variant={service.status === 'connected' ? 'success' : 'secondary'}
                    >
                      {service.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {service.description}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                {service.status === 'connected' ? (
                  <>
                    <Button 
                      variant="outline" 
                      onClick={() => handleConnect(service)}
                    >
                      Update API Key
                    </Button>
                    <Button 
                      variant="outline"
                      className="text-red-500 hover:text-red-600"
                      onClick={() => handleDisconnect(service.id)}
                    >
                      Disconnect
                    </Button>
                  </>
                ) : (
                  <Button 
                    className="bg-green-500 hover:bg-green-600 text-white"
                    onClick={() => handleConnect(service)}
                  >
                    Connect
                  </Button>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Dialog open={showApiKeyDialog} onOpenChange={setShowApiKeyDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {selectedService?.status === 'connected' 
                ? `Update ${selectedService.name} API Key` 
                : `Connect to ${selectedService?.name}`}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="api-key">API Key</Label>
              <Input
                id="api-key"
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="Enter your API key"
              />
            </div>
            
            <div className="text-sm text-muted-foreground">
              Your API key will be encrypted and stored securely. We never share your API keys with third parties.
            </div>
            
            <div className="flex justify-end gap-3 pt-4">
              <Button 
                variant="outline" 
                onClick={() => setShowApiKeyDialog(false)}
              >
                Cancel
              </Button>
              <Button 
                className="bg-green-500 hover:bg-green-600 text-white"
                onClick={handleSaveApiKey}
              >
                Save API Key
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};