import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";

export const InvoiceTemplateSettings = () => {
  const [selectedTemplate, setSelectedTemplate] = useState("default");

  const handleSave = () => {
    toast.success("Invoice template updated successfully");
  };

  return (
    <div className="max-w-4xl">
      <h2 className="text-lg font-medium mb-6">Invoice templates</h2>

      <div className="grid grid-cols-3 gap-6 mb-8">
        {["default", "professional", "minimal"].map((template) => (
          <Card
            key={template}
            className={`p-4 cursor-pointer border-2 transition-colors ${
              selectedTemplate === template 
                ? "border-primary" 
                : "border-border hover:border-primary/50"
            }`}
            onClick={() => setSelectedTemplate(template)}
          >
            <div className="aspect-[3/4] bg-muted rounded mb-3" />
            <div className="font-medium capitalize text-center">
              {template} template
            </div>
          </Card>
        ))}
      </div>

      <div className="flex justify-end">
        <Button 
          className="bg-green-500 hover:bg-green-600 text-white"
          onClick={handleSave}
        >
          Save changes
        </Button>
      </div>
    </div>
  );
};