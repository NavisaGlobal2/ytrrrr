import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { BusinessProfile } from "@/types/settings";

const INDUSTRIES = [
  "Information technology services",
  "Software development",
  "E-commerce",
  "Consulting",
  "Healthcare",
  "Education",
  "Manufacturing",
  "Retail",
  "Other"
];

const TIMEZONES = [
  "(UTC +1:00) Africa Lagos",
  "(UTC +0:00) London",
  "(UTC -5:00) New York",
  "(UTC -8:00) Los Angeles",
  "(UTC +8:00) Singapore"
];

export const BusinessProfileSettings = () => {
  const [profile, setProfile] = useState<BusinessProfile>({
    name: "Amarachhhiii LTD",
    industry: "Information technology services",
    email: "Amarachhhiii@gmail.com",
    timezone: "(UTC +1:00) Africa Lagos",
    country: "Nigeria",
    state: "Lagos",
    phone1: "Nigeria",
    address1: ""
  });

  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setLogoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) {
      setLogoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    // Here you would typically save the profile to your backend
    toast.success("Business profile updated successfully");
  };

  return (
    <div className="max-w-4xl space-y-6">
      <div>
        <h2 className="text-lg font-medium mb-4">Business logo</h2>
        <div 
          className="border-2 border-dashed rounded-lg p-6"
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
        >
          {logoPreview ? (
            <div className="flex items-center justify-center">
              <img 
                src={logoPreview} 
                alt="Business logo" 
                className="max-h-32 object-contain"
              />
            </div>
          ) : (
            <div className="text-center">
              <div className="text-gray-400 mb-2">Drag & drop file here</div>
              <div className="text-gray-400 mb-4">Or</div>
              <Button 
                variant="outline"
                onClick={() => document.getElementById('logo-upload')?.click()}
              >
                Browse files
              </Button>
              <input
                id="logo-upload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleLogoChange}
              />
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="business-name">Business name</Label>
          <Input
            id="business-name"
            value={profile.name}
            onChange={(e) => setProfile({ ...profile, name: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="business-industry">Business industry</Label>
          <Select 
            value={profile.industry}
            onValueChange={(value) => setProfile({ ...profile, industry: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select industry" />
            </SelectTrigger>
            <SelectContent>
              {INDUSTRIES.map((industry) => (
                <SelectItem key={industry} value={industry}>
                  {industry}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="business-email">Business email address</Label>
          <Input
            id="business-email"
            type="email"
            value={profile.email}
            onChange={(e) => setProfile({ ...profile, email: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="business-timezone">Business time-zone</Label>
          <Select 
            value={profile.timezone}
            onValueChange={(value) => setProfile({ ...profile, timezone: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select timezone" />
            </SelectTrigger>
            <SelectContent>
              {TIMEZONES.map((timezone) => (
                <SelectItem key={timezone} value={timezone}>
                  {timezone}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="country">Country</Label>
          <Select 
            value={profile.country}
            onValueChange={(value) => setProfile({ ...profile, country: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select country" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Nigeria">Nigeria</SelectItem>
              {/* Add more countries as needed */}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="state">State</Label>
          <Select 
            value={profile.state}
            onValueChange={(value) => setProfile({ ...profile, state: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select state" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Lagos">Lagos</SelectItem>
              {/* Add more states as needed */}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="phone1">Business phone 1</Label>
          <Input
            id="phone1"
            value={profile.phone1}
            onChange={(e) => setProfile({ ...profile, phone1: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="phone2">Business phone 2 (Optional)</Label>
          <Input
            id="phone2"
            value={profile.phone2 || ''}
            onChange={(e) => setProfile({ ...profile, phone2: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="address1">Address 1</Label>
          <Input
            id="address1"
            value={profile.address1}
            onChange={(e) => setProfile({ ...profile, address1: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="address2">Address 2 (Optional)</Label>
          <Input
            id="address2"
            value={profile.address2 || ''}
            onChange={(e) => setProfile({ ...profile, address2: e.target.value })}
          />
        </div>
      </div>

      <div className="flex justify-end">
        <Button 
          className="bg-green-500 hover:bg-green-600 text-white"
          onClick={handleSave}
        >
          Save changes
        </Button>
      </div>
    </div>
  );
};