import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { NotificationSettings as NotificationSettingsType } from "@/types/settings";
import { toast } from "sonner";

export const NotificationSettings = () => {
  const [settings, setSettings] = useState<NotificationSettingsType>({
    emailNotifications: true,
    pushNotifications: false,
    smsNotifications: true
  });

  const handleSave = () => {
    toast.success("Notification settings updated successfully");
  };

  return (
    <div className="max-w-4xl">
      <h2 className="text-lg font-medium mb-6">Notification preferences</h2>

      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Label className="text-base">Email notifications</Label>
            <p className="text-sm text-muted-foreground">
              Receive notifications about your account via email
            </p>
          </div>
          <Switch
            checked={settings.emailNotifications}
            onCheckedChange={(checked) => 
              setSettings({ ...settings, emailNotifications: checked })
            }
          />
        </div>

        <div className="flex items-center justify-between">
          <div>
            <Label className="text-base">Push notifications</Label>
            <p className="text-sm text-muted-foreground">
              Receive notifications through your browser
            </p>
          </div>
          <Switch
            checked={settings.pushNotifications}
            onCheckedChange={(checked) => 
              setSettings({ ...settings, pushNotifications: checked })
            }
          />
        </div>

        <div className="flex items-center justify-between">
          <div>
            <Label className="text-base">SMS notifications</Label>
            <p className="text-sm text-muted-foreground">
              Receive important notifications via SMS
            </p>
          </div>
          <Switch
            checked={settings.smsNotifications}
            onCheckedChange={(checked) => 
              setSettings({ ...settings, smsNotifications: checked })
            }
          />
        </div>

        <div className="flex justify-end pt-6">
          <Button 
            className="bg-green-500 hover:bg-green-600 text-white"
            onClick={handleSave}
          >
            Save changes
          </Button>
        </div>
      </div>
    </div>
  );
};