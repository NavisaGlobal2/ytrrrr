import { useState } from "react";
import { Button } from "@/components/ui/button";
import { TeamMember } from "@/types/settings";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export const TeamManagementSettings = () => {
  const [members] = useState<TeamMember[]>([
    {
      id: '1',
      name: 'Amarachi',
      email: 'amarachi@example.com',
      role: 'admin',
      status: 'active'
    },
    {
      id: '2',
      name: 'John Doe',
      email: 'john@example.com',
      role: 'member',
      status: 'active'
    }
  ]);

  const handleInvite = () => {
    toast.success("Invitation sent successfully");
  };

  return (
    <div className="max-w-4xl">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-lg font-medium">Team members</h2>
        <Button 
          className="bg-green-500 hover:bg-green-600 text-white"
          onClick={handleInvite}
        >
          Invite team member
        </Button>
      </div>

      <div className="border rounded-lg divide-y">
        {members.map((member) => (
          <div key={member.id} className="p-4 flex items-center justify-between">
            <div>
              <div className="font-medium">{member.name}</div>
              <div className="text-sm text-muted-foreground">{member.email}</div>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant={member.status === 'active' ? 'success' : 'secondary'}>
                {member.status}
              </Badge>
              <Badge variant="outline">{member.role}</Badge>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};